<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Сапа-Зергер тауарлары</title>
	<?php
	require_once 'php/_head.php';
	?>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top scrolling-navbar">
                <a class="navbar-brand" href="/index.php">
                    Sapa-Zerger
                </a>
                <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbarSupportedContent" data-toggle="collapse" type="button" style="float: right;">
                    <i class="fa fa-filter navbar-toggler"></i>
                    </span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarSupportedContent" style="width: 100%;">
                	<form action="#" id="filter_form" method="POST" style="">
                    <ul class="navbar-nav" >
                    	<!-- <li class="nav-item">IIII</li> -->

                        
                        <li class="nav-item active">
                            <div class="form-group">
								<select class="form-control form-control-sm" id="category" name="category">
									<option value="Барлық">Барлық тауарлар</option>
									<option value="Білезік">Білезік</option>
									<option value="Алқа">Алқа</option>
									<option value="Жүзік">Жүзік</option>
									<option value="Сырға">Сырға</option>
								</select>
							</div>
                        </li>
                        <li class="nav-item ">
				                <input type="number" id="min" name="min" class="form-control form-control-sm" placeholder="Минималды баға">
                        </li>
                         <!-- <li class="nav-item">IIII</li> -->
                        <li class="nav-item">
				                <input type="number" id="max" name="max" class="form-control form-control-sm" placeholder="Максималды баға">		               
                        </li>

                         <!-- <li class="nav-item">IIII</li> -->
                         <li class="nav-item active">
                            <div class="form-group">
								<select class="form-control form-control-sm" id="price" name="price">
									<option value="Барлық">Аралас</option>
									<option value="Арзан">Арзан</option>
									<option value="Қымбат">Қымбат</option>
								</select>
							</div>
                        </li>
                        <!-- <li class="nav-item">IIII</li> -->
                        <li class="nav-item dropdown">
                        	<input type="hidden" name="button" id="action" value="ok" class="btn btn-success btn-sm mb-0">
                        	<input type="submit" name="button" value="ok" class="btn btn-success btn-sm mb-0">
                        </li>
         
                    </ul>
                </form>
                 <form class="form-inline" id="search_form">
                        <input aria-label="Search" class="form-control form-control-mr-sm-2" style="width:60%;float: left;" placeholder="..." type="search">
                            <button class="btn btn-success btn-sm mb-0" style="width:30%;float: right;" type="submit">
                                Іздеу
                            </button>
                        </input>
                    </form>
                </div> 
              
            </nav>
        
            <br /><br /><br><br>
            <main class="mt-5">
    <div class="container">
     <section id="products" class="text-center">
       <h2 class="mb-5 font-weight-bold">Тауарлар</h2>

       <div id="display_products" class="row">

 
       </div>
     </section>
 </div>
</main>
 <script type="text/javascript">
	$(document).ready(function() {
		dislay_products();
		function dislay_products(){
			action ="все";
				$.ajax({
					url: "php/select_class.php",
					type: "POST",
					data: ({action: action}),
					dataType: "html",
					success: function(data){
						$("#display_products").html(data);
					}
				});
			}
		$('#filter_form').on('submit',(function(e) {
			e.preventDefault();
			$.ajax({
		        	url: "php/filter_class.php",
					type: "POST",
					data:  new FormData(this),
					contentType: false,
		    	    cache: false,
					processData:false,
					success: function(data)
				    {
				    	// alert(data);
				    	$("#display_products").html(data);
				    }
				});
		}));
		});
	</script>
              <!-- jQuery -->
  <script type="text/javascript" src="js/jquery.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
 
</body>
</html>