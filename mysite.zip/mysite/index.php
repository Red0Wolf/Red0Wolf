<?php
 require_once 'php/_header.php';
?>

  <main class="mt-5">
    <div class="container">
     <section id="service" class="text-center">
       <h2 class="mb-5 font-weight-bold">Сапа-Зергер шеберхана қызметтер!!!</h2>
        <div class="row d-flex justify-content-center mb-4">
          <div class="col-md-8">
            <p class="grey-text">
              Сапа-Зергерлік шеберханасы зергерлік бұйымдарыдың келесі келесідей қызметтерді сізге ұсынады
            </p>

          </div>
        </div>
        <div class="row">
          <div class="col-md-4 mb-5">
            <i class="fa fa-book fa-4x grey-text"></i>
            <h4 class="my-4 font-weight-bold">Тапсырыс</h4>
            <p class="grey-text">Сапа-Зергер зергерлік шеберханасынан өзіңізге ұнайтын әшекейлерді арнайы тапсырыс арқылы қабылдайды </p>
          </div>
           <div class="col-md-4 mb-5">
            <i class="fa fa-truck fa-4x grey-text"></i>
            <h4 class="my-4 font-weight-bold">Жеткізу</h4>
            <p class="grey-text">Берілген тапсырыс бойынша жеткізу қызметтерін таңдауға болады. Мысалы Казпочта, поезд, т.б және Шымкент қаласы бойынша жеткізу қызметі</p>
          </div>
           <div class="col-md-4 mb-5">
            <i class="fa fa-shopping-cart fa-4x grey-text"></i>
            <h4 class="my-4 font-weight-bold">Төлем</h4>
            <p class="grey-text">Тапсырысқа төлем жасау Каспий Голд арқылы жүзеге асырылады. Және тапсырыс алдын сезімділік төлем ақы талап етіледі.</p>
          </div>
        </div>
     </section>

     <hr class="my-5"></hr>

     <section id="products" class="text-center">
       <h2 class="mb-5 font-weight-bold">Тауарлар</h2>

       <div class="row">

        <?php
        $result = $mysqli->query('SELECT * FROM `products` ORDER BY RAND() LIMIT 6');
        $i = 0;

        while (($row=$result->fetch_assoc())!=false) {

          if ($i%3==0) {
            ?>

            <div class="col-lg-4 col-md-12 mb-4 ">
           <div class="view overlay zoom product-img1">
             <img <?php echo "src=\"img/$row[img]\"";?> class="img-flid" />
             <div class="mask flex-center rgba-red-strong"></div>
           </div>
           <h4 class="my-4 font-weight-bold"><?php echo "$row[title]";?></h4>
           <p class="grey-text"><?php echo "$row[price]" ;?>тг</p>
         </div>
         <?php
          } else{ ?>

            <div class="col-lg-4 col-md-6 mb-4" >
           <div class="view overlay zoom product-img">
             <img <?php echo "src=\"img/$row[img]\"";?> class="img-flid" />
             <div class="mask flex-center rgba-red-strong"></div>
           </div>
           <h4 class="my-4 font-weight-bold"><?php echo "$row[title]";?></h4>
           <p class="grey-text"><?php echo "$row[price]" ;?>тг</p>
         </div>

         <?php
          }
          $i++;
        }
        ?>
       </div>
       <div class="text-center mt-4">
                <a href="products.php"><button class="btn btn-primary waves-effect waves-light">Басқада тауарлар...<!-- <i class="fas fa-paper-plane ml-1"></i> --></button></a>
              </div>
     </section>

      <hr class="my-5"></hr>

      <section id="adress">
        <h2 class="mb-5 font-weight-bold text-center">Байланыс</h2>
        <div class="row">
          <div class="col-lg-5 col-md-12">
            <form action="#" class="p-5">
              <div class="md-form form-sm">
                <i class="fa fa-user prefix grey-text"></i>
                <input type="text" id="form3" class="form-control form-control-sm">
                <label for="form3">Атыңыз</label>
              </div>
              <div class="md-form form-sm">
                <i class="fa fa-envelope prefix grey-text"></i>
                <input type="text" id="form2" class="form-control form-control-sm">
                <label for="form2">Почта</label>
              </div>
              <div class="md-form form-sm">
                <i class="fa fa-tag prefix grey-text"></i>
                <input type="text" id="form1" class="form-control form-control-sm">
                <label for="form1">Тема</label>
              </div>
              <div class="md-form form-sm">
                <i class="fa fa-pencil prefix grey-text"></i>
                <textarea type="text" id="form0" class="md-textarea form-control form-control-sm" rows="3"></textarea>
                <label for="form0">Хабарлама</label>
              </div>
              <div class="text-center mt-4">
                <button class="btn btn-primary waves-effect waves-light">Жөнелту <i class="fas fa-paper-plane ml-1"></i></button>
              </div>
            </form>
          </div>
          <div class="col-lg-7 col-md-12">
            <div class="row text-center">
              <div class="col-lg-4 col-md-12 mb-3">
                <p><i class="fa fa-map fa-1x mr-2 grey-text"></i>Шымкент</p>
              </div>
               <div class="col-lg-4 col-md-6 mb-3">
                 <p><i class="fa fa-building fa-1x mr-2 grey-text"></i>Дн-Жк</p>
               </div>
                <div class="col-lg-4 col-md-6 mb-3">
                  <p><i class="fa fa-phone fa-1x mr-2 grey-text"></i>+7 771 884 99 16</p>
                </div>
            </div>
            <!--Google map-->
<div id="map-container-google-2" class="z-depth-1-half map-container" style="height: 400px">
  <iframe src="https://maps.google.com/maps?q=43.311793,69.609644&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0"
    style="border:0; width: 100%; height: 100%;" allowfullscreen></iframe>
</div>

<!--Google Maps-->
          </div>
        </div>
      </section>
    </div>
  </main>

 <?php require_once 'php/_footer.php'; ?>

</body>
</html>
