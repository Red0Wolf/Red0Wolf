<?php
	sleep(1);
	echo "Контент ".$_POST["a"]." ".$_POST["b"];
?>