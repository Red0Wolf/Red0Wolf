<?php
session_start();
$root = $_SERVER['DOCUMENT_ROOT'];
if (isset($_SESSION['login']) && $_SESSION['login'] == 'on' )
	{
		//on
	}
  else
  {
    header('Location: login.php');
  }
?>

<!DOCTYPE html>
<html lang="en">
<head>
	<title>Sapa-Zerger-қызметкерлері</title>
	<?php require_once $root."/php/_head.php "?>

  
	

</head>
<body>
	<?php require_once "_header_admin.php "?>
<section>
	<div class="container box">
		<h3 align="center">Тауарлары басқару</h3>
		<form id="insert_form" method="post" class="insert_form">
			<label>Аты</label>
			<input type="text" name="title" id="title" class="form-control" />
			<label>Бағасы</label>
			<input type="text" name="price" id="price" class="form-control" />
			<label>Суреті</label>
			<input type="file" name="image" id="image" class="form-control-file" accept="image/*" />
			<label>Категория</label>
			<div class="form-group">
				<select class="form-control" id="category" name="category">
					<option value="Білезік">Білезік</option>
					<option value="Алқа">Алқа</option>
					<option value="Жүзік">Жүзік</option>
					<option value="Сырға">Сырға</option>
				</select>
			</div>
			
			<div align="center">
				<input type="hidden" name="id" id="name_id">
				<input type="hidden" name="action" id="action" value="">
				
				<input type="submit" name="button" id="button" value="Add" class="btn btn-warning">
				<!-- <button type="submit" name="button" id="button" class="btn btn-warning">insert</button> -->
			</div>
		</form>
		<div class="img_display" id="img_display">
		</div>
		
	</div>
	<div id="result" class="table-responsive">
			
	</div>
</section>
<script type="text/javascript">
	$(document).ready(function () {
		fetchUser();
		function fetchUser()
		{
			var action = $('#action').val();
			$.ajax({
				url: "select.php",
				type:"POST",
				data: {action: action},
				success: function(data){
					$('#insert_form')[0].reset();
					$('#title').val('');
					$('#price').val('');
					$('#image').val('');
					$('#result').html(data);
					$('#img_display').html('');
					$('#action').val('add');
					$('#button').val('Add');
				}
			});
		}
		$('#insert_form').on('submit',(function(e) {
			e.preventDefault();
			var action = $('#action').val();
			if (action == '') {
				alert('xx');
				return false;
			}
			var title = $('#title').val();
			if (title == '') {
				alert('Тауар атын енгізіңіз!!!');
				return false;
			}
			var price = $('#price').val();
			if (price == '') {
				alert('Тауар бағасын енгізіңіз!!!');
				return false;
			}
				$.ajax({
		        	url: "insert.php",
					type: "POST",
					data:  new FormData(this),
					contentType: false,
		    	    cache: false,
					processData:false,
					success: function(data)
				    {
				    	alert(data);
				    	fetchUser();
				    },
				  	error: function() 
			    	{

			    	} 	        
		   });
		}));
		$(document).on('click','.update',function(e) {
			// alert("xx");
			var id = $(this).attr("id");
			
			$.ajax({
				url:"fetch.php",
				type:"POST",
				data:{id:id},
				dataType:"json",
				success:function (data) {
					$('#button').val("Update");
					$('#action').val("update");
					$('#name_id').val(id);
					$('#title').val(data.title);
					$('#price').val(data.price);
					$('#img_display').html(data.img);
					$('#category').val(data.category);
					// alert(data.img);
				}
			});
		});
		$(document).on('click','.delete',function(e) {
			var action = "delete";
			var name_id = $(this).attr("id");
			if(confirm("Сіз осы тауарды бір жола жоюды қалайсызба?"))
			{
				$.ajax({
					url:'insert.php',
					type:'POST',
					data:{id: name_id, action:action},
					success:function (data) {
						alert(data);
						fetchUser();
					}
				});
			}else{

			}
		});
	});
</script>

<?php require_once $root.'/php/_footer.php'; ?>
</body>
</html>
