<?php
  $root = $_SERVER['DOCUMENT_ROOT'];
  require_once $root.'/php/_head.php';
  if (isset($_SESSION['login']) && $_SESSION['login'] == 'on') {
    # code...
?>	
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top scrolling-navbar">
	<a class="navbar-brand" href = "#">Sapa-zerger қызметкерлері</a>


	<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">

    <span class="navbar-toggler-icon"></span>
  </button>

   <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav mr-auto smooth-scroll">
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light" href="#intro">Басты бет</a>
      </li>
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light" href="#table">Тауарлар</a>
      </li>
      <!-- <li class="nav-item">
        <a class="nav-link waves-effect waves-light" href="#adres">Адрес</a>
      </li> -->
      <!-- <li class="nav-item waves-effect waves-light">
        <a class="nav-link disabled" href="#">Біз жайында</a>
      </li> -->
    </ul>
    <ul class="navbar-nav nav-flex-icons">
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light" href="#">
          <i class="fa fa-user"></i> Admin
        </a>
      </li>  
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light" href="stop.php">
          <i class="fa fa-close"></i>шығу
        </a>
      </li> 
    </ul>
  </div>  
<?php 
  }else{
    //off
?>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary scrolling-navbar">
  <a class="navbar-brand" href = "#" align ="center">Sapa-zerger қызметкерлері</a>
  <?php 
  }
?>
</nav>