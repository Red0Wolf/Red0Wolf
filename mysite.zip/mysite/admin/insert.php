<?php
// echo $_FILES['image']['name'];
// echo $_POST['title'];
// echo $_POST['category'];


$root = $_SERVER['DOCUMENT_ROOT'];
require_once $root.'/php/db_class.php';

	// $action=$_POST['action']);


if (isset($_POST["action"])) {
	$newImgname = "1.jpg";
	if($_POST["action"]=="add"){
		$title = $_POST['title'];
		$price = $_POST['price'];
		$category = $_POST['category'];
	if(isset($_FILES['image'])&&$_FILES['image']['tmp_name']!=''){
		$uploaddir = $root.'/img/';
		$newImgname =date('YmdHis').rand(100,1000).'.jpg';
		 $uploadfile = "$uploaddir$newImgname";
		  if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) 
         {
         	
         }
    }
     $sql =$mysqli->query("INSERT INTO products (`id`, `title`, `price`, `img`, `category`) VALUES (NULL, '$title', '$price', '$newImgname', '$category');");
         	if ($sql) {
         		echo "Тауар қосылды!!!";
         	}else{
         		echo "Ақаулық пайда болды";
         	}

}
else if($_POST["action"]=="update")
{
	if(isset($_POST['id']))
	{
		$id = $_POST['id'];
		$sql =$mysqli->query("SELECT * FROM products WHERE `id` ={$id}");

		if($sql){
			while ($row = mysqli_fetch_array($sql)) {
			$newImgname = $row['img'];
			}
		}
	}
	
 	if(isset($_FILES['image'])&&$_FILES['image']['tmp_name']!=''){
		$uploaddir = $root.'/img/';
		$newImgname =date('YmdHis').rand(100,1000).'.jpg';
		 $uploadfile = "$uploaddir$newImgname";
		  if (move_uploaded_file($_FILES['image']['tmp_name'], $uploadfile)) 
         {
         	
         }
    }
    $sql = $mysqli->query("UPDATE products SET `title` = '{$_POST['title']}',`price` = '{$_POST['price']}',`img` = '{$newImgname}',`category` = '{$_POST['category']}' WHERE `id`={$_POST['id']}");
         	if ($sql) {
         		echo "Тауар өзгертілді!!!";
         	}else{
         		echo "Ақаулық пайда болды";
       }
}else if ($_POST['action']=='delete') {
	if(isset($_POST['id']))
	{
		$id = $_POST['id'];
		$sql =$mysqli->query("SELECT * FROM products WHERE `id` ={$id}");

		if($sql){
			while ($row = mysqli_fetch_array($sql)) {
			$newImgname = $row['img'];
			}
		}
	}

	 $sql = $mysqli->query("DELETE FROM `products` WHERE `products`.`id`={$_POST['id']}");

         	if ($sql) {
         		unlink($root.'/img/'.$newImgname);
         		echo "Тауар базадан жойылды!!!";
         	}else{
         		echo "Ақаулық пайда болды";
       }
}else{
	echo "Ақаулық пайда болды";
}
 
}else
{
   	echo "Ақаулық пайда болды";
}

?>