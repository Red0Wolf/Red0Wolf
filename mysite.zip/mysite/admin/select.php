<?php
	$root = $_SERVER['DOCUMENT_ROOT'];
	require_once $root.'/php/db_class.php';

	$output = '';
	if (isset($_POST["action"])) {
	$sql = "SELECT * FROM products ORDER BY id DESC";
	$result = mysqli_query($mysqli,$sql);

	$output .='
		<div class="table-responsive" id="table" align="center">
		<table class="table table-bordered">
				<tr>
					<th width="5%">Id</th>
					<th width="20%">Title</th>
					<th width="10%">Price</th>
					<th width="20%">Img</th>
					<th width="20%">Category</th>
					<th width="10%">Update</th>
					<th width="10%">Delete</th>
				</tr>
	';
	if(mysqli_num_rows($result) > 0){
		while($row = mysqli_fetch_array($result))
		{
			$output .= '<tr>
			<td>'.$row["id"].'</td>
			<td>'.$row["title"].'</td>
			<td>'.$row["price"].'</td>
			<td><img src="/img/'.$row["img"].'" alt="img" width="50" width="50"></td>
			<td>'.$row["category"].'</td>
			<td><button name="update" id="'.$row["id"].'" class="update btn btn-success btn-sm mb-0">Update</button></td>
			<td><button name="delete" id="'.$row["id"].'" class="delete btn btn-success btn-sm mb-0">Delete</button></td>

			</tr>

			';
		}
	}
	else
	{
		$output .='<tr>
			<td colspan="7">Data not Found</td>
		</tr>';	
	}
$output.='</table>
</div>';
}
echo $output;
?>