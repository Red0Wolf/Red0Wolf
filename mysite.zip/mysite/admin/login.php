<!-- white-plate -->
<?php
session_start();
$root = $_SERVER['DOCUMENT_ROOT'];
require_once $root.'/php/_head.php';
require_once '_header_admin.php';

ini_set("gc_maxlifetime",20000);
?>
  <div class="white-plate white-plate--login">
    <div class="container-fluid" align ="center">

      <form action="/php/check-login.php" class="form-line" method="POST">
        <div class="form-group">
          <input name="password" type="password" class="form-control" placeholder="Пароль">
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary btn-block">Войти</button>
        </div>
      </form>
      <p class="text-center"><a href="index.php" class="text-secondary">Вернуться назад</a></p>
    </div>
  </div>
  <!-- // white-plate -->

  <!-- Footer -->
    <?php
      require_once $root.'/php/_footer.php';
    ?>
  <!-- // Footer -->