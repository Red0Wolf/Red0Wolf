<?php
	$root = $_SERVER['DOCUMENT_ROOT'];
	require_once $root.'/php/db_class.php';
	if(isset($_POST['id']))
	{
		$id = $_POST['id'];
		$output = array();
		$sql =$mysqli->query("SELECT * FROM products WHERE `id` ={$id}");

		if($sql){
			while ($row = mysqli_fetch_array($sql)) {
				$output['title'] = $row['title'];
				$output['price'] = $row['price'];
				$output['img'] ='<img src="/img/'.$row['img'].'" alt="img" width="300" heigth="350">';
				$output['category'] = $row['category'];
			}
			echo json_encode($output);
		}
	}
	
?>