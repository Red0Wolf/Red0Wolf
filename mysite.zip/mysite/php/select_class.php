 <?php
  require_once 'db_class.php';
  
    $sql="SELECT * FROM products";

  $result = $mysqli->query($sql);
  $i = 0;
  while (($row=$result->fetch_assoc())!=false) {
?>


            <div class="col-lg-4 col-md-6 mb-4" >
           <div class="view overlay zoom product-img">
             <img <?php echo "src=\"/img/$row[img]\"";?> class="img-flid" />
             <div class="mask flex-center rgba-red-strong"></div>
           </div>
           <h4 class="my-4 font-weight-bold"><?php echo "$row[title]";?></h4>
           <p class="grey-text"><?php echo "$row[price]" ;?>тг</p>
         </div>
         <?php
          $i++;
        }

?>