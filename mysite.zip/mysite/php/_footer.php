 <footer class="page-footer font-small unique-color-dark pt-0">
    <div class="primary-color">
      <div class="container">
        <div class="row py-4 d-flex align-items-center">
          <div class="col-md-6 col-lg-5 text-center text-md-left mb-4  mb-md-0">
            <h6 class="mb-0 white-text">Әлеметтік желі арқылы байланыс!</h6>
          </div>
          <div class="col-md-6 col-lg-7 text-center text-md-right">
            <a class="fb-ic.ml-0" href="#">
              <i class="fa fa-instagram white-text mr-4"></i>
            </a>
            <a class="fb-ic.ml-0" href="#">
              <i class="fa fa-facebook white-text mr-4"></i>
            </a>
            <a class="fb-ic.ml-0" href="#">
              <i class="fa fa-whatsapp white-text mr-4"></i>
            </a>
          </div>
        </div>
      </div>
    </div>

    <div class="container text-center text-md-left">
      <div class="row mt-3">
        <div class="col-mb-3 col-lg-4 col-xl-3 mb-4">
          <h6 class="text-uppercase font-weight-bold"><strong>Sapa-Zerger</strong></h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px">
          <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Eaque at molestias alias?</p>
        </div>
        <div class="col-mb-3 col-lg-4 col-xl-3 mb-4">
          <h6 class="text-uppercase font-weight-bold"><strong>Products</strong></h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px">
          <p><a href="#">WWWWWWWW</a></p>
          <p><a href="#">WWWWWWWW</a></p>
          <p><a href="#">WWWWWWWW</a></p>
        </div>
         <div class="col-mb-3 col-lg-4 col-xl-3 mb-4">
          <h6 class="text-uppercase font-weight-bold"><strong>Products</strong></h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px">
          <p><a href="#">Account</a></p>
          <p><a href="#">Help</a></p>
          <p><a href="#">WWWW</a></p>
        </div>
        <div class="col-mb-4 col-lg-3 col-xl-3">
          <h6 class="text-uppercase font-weight-bold"><strong>Contact</strong></h6>
          <hr class="deep-purple accent-2 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px">
          <p><i class="fa fa-home mr-3"></i>Shymkent</p>
          <p><i class="fa fa-envelope mr-3"></i>abs@gmail.com</p>
          <p><i class="fa fa-phone mr-3"></i>+7 771 884 99 16</p>
        </div>
      </div>
    </div>
    <div class="container align-items-center text-center">
      <p class="text-uppercase font-weight-bold"><strong>Made by @Roma_prog <a href="#"><i class="fa fa-phone mr-3"></i></a></strong></p>
    </div>
    <div class="container"></div>
  </footer>

   <!-- jQuery -->
  <!-- <script type="text/javascript" src="/js/jquery.min.js"></script> -->
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="/js/mdb.min.js"></script>
  <!-- Your custom scripts (optional) -->
</body>
</html>

<?php $mysqli->close();?>