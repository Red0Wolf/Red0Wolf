<?php
require_once 'db_class.php';
// $sql="SELECT * FROM `products` WHERE price = '5000' AND category ='Жүзік'";
$sql = "";
if (isset($_POST['button'])) {
	

	if (isset($_POST['category'])) {
		if ($_POST['category']=='Білезік') {
			$sql ="SELECT * FROM products WHERE category ='Білезік'";
		}else if ($_POST['category']=='Сырға') {
			$sql ="SELECT * FROM products WHERE category ='Сырға'";
		}else if ($_POST['category']=='Жүзік') {
			$sql ="SELECT * FROM products WHERE category ='Жүзік'";
		}else if ($_POST['category']=='Алқа') {
			$sql ="SELECT * FROM products WHERE category ='Алқа'";
		}else{
			  $sql="SELECT * FROM products";
		}
		}else
	{
	    $sql="SELECT * FROM products";
	    // echo $_POST['category'];
	}

	if (isset($_POST['price'])) {
		if($_POST['price'] == 'Арзан') {
			$sql .= " ORDER BY `price` ASC";
		}else if ($_POST['price'] == 'Қымбат') {
			$sql .= " ORDER BY `price` DESC";
		}
	else{
		//rr
	}

	}
	
}
else
{
    $sql="SELECT * FROM products";
	    // echo $_POST['category'];
}


$result = $mysqli->query($sql);
  $i = 0;

 if (isset($_POST['min'])) {
 	if ($_POST['min']=='') {
 		$_POST['min']=0;
 	}
 }

 if (isset($_POST['max'])) {
 	if ($_POST['max']=='') {
 		$_POST['max']=100000000000;
 	}
 }
  while (($row=$result->fetch_assoc())!=false) {
  	if ($_POST['min']<=$row['price']&&$_POST['max'] >= $row['price']) {
  		# code...
             ?>
            <div class="col-lg-4 col-md-6 mb-4" >
           <div class="view overlay zoom product-img">
             <img <?php echo "src=\"/img/$row[img]\"";?> class="img-flid" />
             <div class="mask flex-center rgba-red-strong"></div>
           </div>
           <h4 class="my-4 font-weight-bold"><?php echo "$row[title]";?></h4>
           <p class="grey-text"><?php echo "$row[price]" ;?>тг</p>
         </div>

         <?php
     }
          $i++;
        }

?>