<?php
  session_start();
  $root = $_SERVER['DOCUMENT_ROOT'];
// echo "$root/admin/index.php";
  require_once('db_class.php');

  $secretPassword = 'admin';

  if ( $_POST['password'] == $secretPassword )
  {
		$_SESSION['login'] = 'on';
		header("Location: /admin/index.php");
	}
  else
  {
		header("Location: /admin/login.php");
	}
?>
