<!DOCTYPE html>
<html lang="ru">
<head>
  <?php  require_once '_head.php';?>
</head>
<body>

<header> 
 <nav class="navbar navbar-expand-lg navbar-dark top-nav-collase fixed-top scrolling-navbar" id="nav">
                <a class="navbar-brand" href="/index.php">
                    Sapa-Zerger
                </a>
                <button aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler" data-target="#navbarSupportedContent" data-toggle="collapse" type="button">
                    <span class="navbar-toggler-icon">
                    </span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">

    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link waves-effect waves-light" href="#intro">Басты бет</a>
      </li>
      <li class="nav-item waves-effect waves-light">
        <a class="nav-link waves-effect waves-light" href="#service">Қызметтер</a>
      </li>
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light" href="#products">Тауарлар</a>
      </li>
      <li class="nav-item">
        <a class="nav-link disabled waves-effect waves-light" href="#adress">Адрес</a>
      </li>
      <!--     <li class="nav-item">
                            <a class="nav-link disabled" href="#">
                                Disabled
                            </a>
                        </li> -->  
    </ul>
    <ul class="navbar-nav nav-flex-icons">
      <li class="nav-item">
        <a class="nav-link waves-effect waves-light" href="/admin/index.php">
          <i class="fa fa-user"></i> Admin
        </a>
      </li>    
    </ul>
  </div>
</nav>
   
   <div id="intro" class="view">
     <div class="mask rgba-black-strong">
       <div class="container-fluid d-flex align-items-center justify-content-center h-100">
         <div class="row d-flex justify-content-center text-center">
           <div class="col-md-10">
             <h2 class="display-4 font-weight-bold white-text pt-5 mb-2">
              Сапа-Зергер шеберханасы
             </h2>
             <hr class="hr-light" />
             <h4 class="white-text my-4">
               Сапа-Зергер зергерлік шеберханасы - сіз ұнататын әшекейлердің падишасы!!!
             </h4>
            </div>
         </div>
       </div>
     </div>
   </div>
  </header>

