<?php

require_once '/PHPMailer/PHPMailerAutoload.php';
 
$mail = new PHPMailer;
$mail->CharSet = 'UTF-8';
 
// Настройки SMTP
$mail->isSMTP();
$mail->SMTPAuth = true;
$mail->SMTPDebug = 0;
 
$mail->Host = 'ssl://smtp.mail.ru';
$mail->Port = 465;
$mail->Username = 'r.mamet@mail.ru';
$mail->Password = 'roma999';

// От кого
$mail->setFrom('r.mamet@mail.ru', 'Sapa-Zerger');		
 
// Кому
$mail->addAddress('r.mamet@bk.ru', 'Иван Петров');
 
// Тема письма
$mail->Subject = $subject;
 
// Тело письма
$body = '<p><strong>«Hello, world!» </strong></p>';
$mail->msgHTML($body);
 
// Приложение
// $mail->addAttachment(__DIR__ . '/image.jpg');
 
$mail->send();

?>